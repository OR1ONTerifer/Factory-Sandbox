# Factory-Sandbox
#### Small hobby game I'm making, inspired by games like Shapez.io and Factorio. This game is current in the pre-alpha stage. There might be bugs and can possibly crash.

## Changelog:

v.0.0.1 (CURRENT): Added base game environment.

## Possible additions:

Tutorial

Cost display for buildings

Upgrader buildings

Save game (probably not tho)

## Controls (will be removed after tutorial is released):

W, A, S, D: Movement

R: Rotate building

Left Mouse: Place building

Right Mouse: Destroy building

Shift: Multi-place